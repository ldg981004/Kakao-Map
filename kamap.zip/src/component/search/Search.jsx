/* eslint-disable */

import React, { useState } from "react";
import Map from '../map/Map';

const SearchPlace = () => {
    const [inputText, setInputText] = useState("");
    const [place, setPlace] = useState("");
    //useState 값 초기화

    const onChange = (e) => {
      setInputText(e.target.value);
    };
  
    const handleSubmit = (e) => {
      e.preventDefault();
      setPlace(inputText);
      setInputText("");
    };

    const valueCheker = () => {
        if(inputText === "") {
            alert("검색어를 입력하세요");
        }
    }
    
    return(
        <div>
            <div>
                <form className="inputForm" onSubmit={handleSubmit}>
                    <input placeholder="검색하세요" onChange={onChange} value={inputText}></input>
                    <button type="submit" onClick={valueCheker}>검색</button>
                </form>
            </div>
            
        </div>
        
    );
}

export default SearchPlace;