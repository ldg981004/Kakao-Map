/* eslint-disable */

/*global kakao*/ 
import './map.css';
import React, {useEffect} from 'react';
import { useState } from 'react';

const {kakao} = window;

function MapTest ({ searchPlace })  {
    const [map,setMap] = useState(null);

    //처음 지도 그리기
    useEffect(()=>{
        //useEffect : 컴포넌트가 렌더링 될 떄 특정 작업을 실행할 수 있도록 하는 Hook
        const container = document.getElementById('map');
        // document.getElementById => 주어진 문자열과 일치하는 id 속성을 가진 요소를 찾고 이를 나타내는 Element 객체를 반환
        // 지도를 표시할 div
        const options = { center: new kakao.maps.LatLng(37.39268742620237, 126.97377807020837),
                          level: 3 };
        // 지도의 option으로 처음 지도가 그려졌을 때 중앙 위치와 확대 레벨(기본3)을 설정

        const kakaoMap = new kakao.maps.Map(container, options);
        // 지도를 표시할 div와 지도 옵션으로 지도를 생성
        setMap(kakaoMap);

        const mapTypeControl = new kakao.maps.MapTypeControl();

        kakaoMap.addControl(mapTypeControl, kakao.maps.ControlPosition.TOPRIGHT);
        // 지도 타입을 설정할 수 있는 Control을 상단 우측에 추가

        const zoomControl = new kakao.maps.ZoomControl();
        kakaoMap.addControl(zoomControl, kakao.maps.ControlPosition.RIGHT);
        // 지도를 확대, 축소 할 수 있는 Control을 우측에 추가

        //const markerPosition = new kakao.maps.LatLng(37.39268742620237, 126.97377807020837);
        // marker의 위치를 지도가 생성될 때 center 위치와 동일하게 설정

        const marker = new kakao.maps.Marker({
            //position: markerPosition,
            // 마커를 하나 생성하고 위치를 markerPosition으로 설정
        });

        marker.setMap(kakaoMap);
        // 마커를 kakaoMap에 띄워줌

        //const iwContent = '<div style="padding:5px; width:100%;">주식회사 세오</div>'
        // 마커의 infoWindow는 '주식회사 세오'

        const infowindow = new kakao.maps.InfoWindow();

        /*kakao.maps.event.addListener(
            marker,
            "mouseover",
            makeOverListener(kakaoMap, marker, infowindow)
        );

        kakao.maps.event.addListener(
            marker,
            "mouseout",
            makeOutListener(infowindow)
        );

        function makeOverListener(kakaoMap, marker, infowindow){
            return function() {
                infowindow.open(kakaoMap, marker)
            };
        }
        
        function makeOutListener(infowindow){
            return function() {
                infowindow.close();
            };
        }
        */

        //infowindow.open(kakaoMap, marker);

        var ps = new kakao.maps.services.Places();
        // 장소 검색 객체를 생성

        ps.keywordSearch(searchPlace, placeSearchCB);
        // 키워드로 장소 검색

        function placeSearchCB (data, status, pagination){
            if (status === kakao.maps.services.Status.OK){
                var bounds = new kakao.maps.LatLngBounds();
                // bounds는 위도 경도를 정의

                for(var i = 0; i < data.length; i++){
                    displayMarker(data[i]);
                    bounds.extend(new kakao.maps.LatLng(data[i].y, data[i].x));
                }
                kakaoMap.setBounds(bounds);
            }
        }

        function displayMarker(place){
            var marker = new kakao.maps.Marker({
                map: kakaoMap,
                position: new kakao.maps.LatLng(place.y, place.x)
            });

            kakao.maps.event.addListener(marker, 'mouseover', function(){
                infowindow.setContent('<div style="padding:5px; color:black; width:100%; font-size:11x;">' + place.place_name + '</div>');
                infowindow.open(kakaoMap, marker);
            });

            kakao.maps.event.addListener(marker,'mouseout', function() {
                infowindow.close();
            });
        }
            
        
    },[searchPlace]);
    //[] => 최초 렌더링 시에만 나옴
    // searchPlace => 할 때 렌더링

    return (
        <div className='board'>
            <div id="map" className='mapboard'></div>
        </div>
    );
};

export default MapTest;