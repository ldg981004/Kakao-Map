/* eslint-disable */

import './App.css';
import Kmap from './component/map/Map';
import Ksearch from './component/search/Search';

function App() {
  return (
    <div className="All">
      <div className='Search'>

        <div className='Top'>
          <Ksearch/>
        </div>

        <div className='Bottom'>

        </div>

      </div>
      <div className='Map'>
        <Kmap/>
      </div>
    </div>
  );
}

export default App;
